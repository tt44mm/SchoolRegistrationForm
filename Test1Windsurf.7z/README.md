# SchoolRegistrationForm
PHP Form für die neuanmeldung für schueler
